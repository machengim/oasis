import React from 'react';

export default function Error404() {
  return <div className="text-md">Not found.</div>;
}
