# MyLib

### TODO

+ [ ] Start page
+ [ ] Scanning video items on local storage
+ [ ] Displaying video items
+ [ ] Streaming video
+ [ ] TMDB search
+ [ ] Dashboard
+ [ ] Version check and update
+ [ ] I18n
+ [ ] Image support
+ [ ] Music support
+ [ ] Server side transcoding
+ [ ] Demo website
+ [ ] Plugin support