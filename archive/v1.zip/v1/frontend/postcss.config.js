const tailwindPlugin = require('tailwindcss');

module.exports = {
	plugins: [tailwindPlugin],
};