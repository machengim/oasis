import React from 'react';

export default function SubTitle(props) {
    return (
        <div className='font-semibold pb-4'>
            {props.title}
        </div>
    );
}