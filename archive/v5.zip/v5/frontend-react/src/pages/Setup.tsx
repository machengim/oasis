import ServerInfoSetupPanel from "../sections/ServerInfoSetupPanel";

export default function Setup() {
  return (
    <div className="w-full h-full">
      <ServerInfoSetupPanel />
    </div>
  );
}
