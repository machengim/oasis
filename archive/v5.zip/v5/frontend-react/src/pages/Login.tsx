export default function Login() {
  return <div className="text-md">Login page</div>;
}
