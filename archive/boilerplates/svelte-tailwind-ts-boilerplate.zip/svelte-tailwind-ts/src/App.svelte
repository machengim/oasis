<script lang="ts">
  export let name: string;
</script>

<main>
  <h1 class="font-bold text-red-400">Hello {name}!</h1>
  <p>
    Visit the <a href="https://svelte.dev/tutorial">Svelte tutorial</a> to learn
    how to build Svelte apps.
  </p>
</main>
